const express = require('express')
const mysql = require('mysql')
const cors = require('cors')
const { json } = require('express')
const app = express()

app.use(express.json())
app.use(cors())
//Establecemos los prámetros de conexión
const conexion = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'usuarios_db'
})
//Conexión a la database
conexion.connect(function(error){
    if(error){
        throw error
    }else{
        console.log("¡Conexión exitosa a la base de datos!")
    }
})
app.get('/', function(req,res){
    res.send('Ruta INICIO')
})
//Mostrar todos los artículos
app.get('/api-c3/usuario', (req,res)=>{
    conexion.query('SELECT * FROM usuario', (error,filas)=>{
        if(error){
            throw error
        }else{
            res.send(filas)
        }
    })
})
//Mostrar un SOLO artículo
app.get('/api-c3/usuario/:id', (req,res)=>{
    conexion.query('SELECT * FROM usuario WHERE id_usuario = ?', [req.params.id], (error, fila)=>{
        if(error){
            throw error
        }else{
            res.send(fila)
        }
    })
})
//Crear un artículo
app.post('/api-c3/usuario', (req,res)=>{
    let data = {nombre:req.body.nombre, apellido:req.body.apellido,email:req.body.email,password:req.body.password}
    let sql = "INSERT INTO usuario SET ?"
    conexion.query(sql, data, function(err, result){
            if(err){
               throw err
            }else{              
             /*Esto es lo nuevo que agregamos para el CRUD con Javascript*/
             Object.assign(data, {id: result.insertId }) //agregamos el ID al objeto data             
             res.send(data) //enviamos los valores                         
        }
    })
})
//Editar articulo
app.put('/api-c3/usuario/:id', (req, res)=>{
    let id = req.params.id
    let nombre = req.body.nombre
    let apellido= req.body.apellido
    let email = req.body.email
    let password = req.body.password
    let sql = "UPDATE usuario SET nombre = ?, apellido = ?, email = ?, password = ? WHERE id_usuario = ?"
    conexion.query(sql, [nombre, apellido, email, password, id], function(error, results){
        if(error){
            throw error
        }else{              
            res.send(results)
        }
    })
})
//Eliminar articulo
app.delete('/api-c3/usuario/:id', (req,res)=>{
    conexion.query('DELETE FROM usuario WHERE id_usuario = ?', [req.params.id], function(error, filas){
        if(error){
            throw error
        }else{              
            res.send(filas)
        }
    })
})
const puerto = process.env.PUERTO || 3000
app.listen(puerto, function(){
    console.log("Servidor Ok en puerto:"+puerto)
})